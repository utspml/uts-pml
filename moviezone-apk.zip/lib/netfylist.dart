import 'package:flutter/material.dart';
import 'package:netfy/netfyview.dart';

class netfylist extends StatefulWidget {
  _netfylistState createState() => new _netfylistState();
}

class _netfylistState extends State<netfylist> {
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.green[800],
        title: Text("Daftar Film", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20.0, color: Colors.white)),
      ),
      backgroundColor: Colors.green[800],
      body: Stack(
        children: <Widget>[
          Container(
            padding: EdgeInsets.all(10.0),
            child: ListView(
              children: <Widget>[
                Center(
                  child: Column(
                    children: <Widget>[
                      //menu 1
                      Column(
                        children: <Widget>[
                          Card(
                            child: Row(
                              children: <Widget>[
                                Image.asset(
                                  "assets/alin.jpg",
                                  width: 70.0,
                                  height: 120.0,
                                ),
                                Expanded(
                                    child: Container(
                                  child: Column(
                                    children: <Widget>[
                                      Text(
                                        'My Girl Friend is Alien',
                                        style: TextStyle(color: Colors.black),
                                      ),
                                      Padding(
                                        padding: EdgeInsets.only(top: 5.0),
                                      ),
                                      Text(
                                        '00:30:00',
                                        style: TextStyle(color: Colors.black),
                                      ),
                                      Padding(
                                        padding: EdgeInsets.only(top: 5.0),
                                      ),
                                      // menu sentuh 1
                                      Container(
                                        width: 200,
                                        height: 45,
                                        child: TextButton(
                                          style: TextButton.styleFrom(
                                            backgroundColor: Colors.green[800],
                                            shape: RoundedRectangleBorder(
                                              borderRadius: BorderRadius.circular(20),
                                            ),
                                          ),
                                          onPressed: () {
                                            Navigator.push(context, MaterialPageRoute(builder: (context) => netfyview()));
                                          },
                                          child: Text(
                                            "Lebih Detail",
                                            style: TextStyle(
                                              color: Color(0xffffffff),
                                            ),
                                          ),
                                        ),
                                      ),
                                      // akhir menu sentuh 1
                                    ],
                                  ),
                                ))
                              ],
                            ),
                          )
                        ],
                      ),
                      //akhir menu 1

                      //menu 2
                      Column(
                        children: <Widget>[
                          Card(
                            child: Row(
                              children: <Widget>[
                                Image.asset(
                                  "assets/setan.jpg",
                                  width: 70.0,
                                  height: 120.0,
                                ),
                                Expanded(
                                    child: Container(
                                  child: Column(
                                    children: <Widget>[
                                      Text(
                                        'Pengabdi Setan',
                                        style: TextStyle(color: Colors.black),
                                      ),
                                      Padding(
                                        padding: EdgeInsets.only(top: 5.0),
                                      ),
                                      Text(
                                        '01:45:00',
                                        style: TextStyle(color: Colors.black),
                                      ),
                                      Padding(
                                        padding: EdgeInsets.only(top: 5.0),
                                      ),
                                      // menu sentuh 2
                                      Container(
                                        width: 200,
                                        height: 45,
                                        child: TextButton(
                                          style: TextButton.styleFrom(
                                            backgroundColor: Colors.green[800],
                                            shape: RoundedRectangleBorder(
                                              borderRadius: BorderRadius.circular(20),
                                            ),
                                          ),
                                          onPressed: () {
                                            Navigator.push(context, MaterialPageRoute(builder: (context) => netfyview()));
                                          },
                                          child: Text(
                                            "Lebih Detail",
                                            style: TextStyle(
                                              color: Color(0xffffffff),
                                            ),
                                          ),
                                        ),
                                      ),
                                      // akhir menu sentuh 2
                                    ],
                                  ),
                                ))
                              ],
                            ),
                          )
                        ],
                      ),
                      //akhir menu 2
                    ],
                  ),
                )
              ],
            ),
          )
        ],
      ),
    );
  }
}

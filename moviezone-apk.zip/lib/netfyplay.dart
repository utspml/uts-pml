import 'package:flutter/material.dart';

class netfyplay extends StatefulWidget {
  _netfyplayState createState() => new _netfyplayState();
}

class _netfyplayState extends State<netfyplay> {
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
      ),
      body: Container(
        color: Colors.black,
        width: double.infinity,
        height: double.infinity,
        // Batas Alas
        child: Center(
          child: Container(
            width: 340,
            height: 280,
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/aliens.jpg'),
                fit: BoxFit.cover,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

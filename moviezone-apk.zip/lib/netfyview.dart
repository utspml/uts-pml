import 'package:flutter/material.dart';
import 'package:netfy/netfyplay.dart';

class netfyview extends StatefulWidget {
  _netfyviewState createState() => new _netfyviewState();
}

class _netfyviewState extends State<netfyview> {
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.green[800],
        actions: <Widget>[
          IconButton(icon: new Icon(Icons.favorite, color: Colors.red[600])),
        ],
      ),
      backgroundColor: Colors.green[800],
      body: Container(
        color: Colors.green[800],
        width: double.infinity,
        height: double.infinity,
        // Batas Alas
        child: Center(
          child: Column(
            children: <Widget>[
              Column(
                children: <Widget>[
                  Padding(
                    padding: EdgeInsets.only(top: 8.0, bottom: 8.0),
                  ),

                  Container(
                    width: 340,
                    height: 280,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10.0),
                      image: DecorationImage(
                        image: AssetImage('assets/alin.jpg'),
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),

                  Padding(
                    padding: EdgeInsets.only(top: 5.0, bottom: 5.0),
                  ),

                  Text('My Girl Friend is Alien', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 28.0, color: Colors.white)),

                  Padding(
                    padding: EdgeInsets.only(top: 3.0, bottom: 3.0),
                  ),

                  Text('00:30:00', style: TextStyle(color: Colors.white)),

                  Padding(
                    padding: EdgeInsets.only(top: 8.0, bottom: 8.0),
                  ),
                  //Sipnosis
                  Text("Sipnosis", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20.0, color: Colors.white)),

                  Container(
                    padding: EdgeInsets.only(left: 8.0, right: 8.0, top: 8.0, bottom: 8.0),
                    child: Align(alignment: Alignment.centerLeft, child: new Text("Sebuah romansa intergalaksi mengikuti seorang gadis alien yang terjebak di planet Bumi, ia bertemu dengan Presiden Direktur yang sombong yang mendapat amnesia akan melupakan lawan jenis setiap kali hujan.", style: TextStyle(color: Colors.white))),
                  ),
                  Padding(
                    padding: EdgeInsets.only(top: 5.0, bottom: 5.0),
                  ),

                  //play button
                  Container(
                    width: 340,
                    height: 45,
                    child: TextButton(
                      style: TextButton.styleFrom(
                        backgroundColor: Colors.blue,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                      onPressed: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) => netfyplay()));
                      },
                      child: Text(
                        "Nonton Sekarang",
                        style: TextStyle(
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                  //end product display
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
